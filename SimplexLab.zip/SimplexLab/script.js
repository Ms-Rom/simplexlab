/* =========================================================
   SimplexLab — script.js
   ---------------------------------------------------------
   EASY EDITS:
   • TEACHER and TEAM below: names, roles, photos.
     To add a photo: put the picture in the "images" folder,
     then write its file name, e.g.  photo: "images/angel.jpg"
   ========================================================= */
const TEACHER = {
  name:    "PTL. Norcelito Galvan",
  subject: "Quantitative Methods",
  photo:   "images/teacher.jpg",
  quote:   "Great teaching is not about delivering answers, but inspiring students to ask deeper questions."
};

const TEAM = [
  { name: "Angel D. Rom",              role: "Project Leader",           photo: "images/angel.jpg" },
  { name: "Dave M. Aponte",            role: "Lead Developer",           photo: "images/dave.jpg" },
  { name: "Ralph Vincent B. Luna",     role: "UI/UX Designer",           photo: "images/ralph.jpg" },
  { name: "Sean Russel Rey B. Luna",   role: "Front-end Developer",      photo: "images/sean.jpg" },
  { name: "Crislene B. Domasig",       role: "Researcher",               photo: "images/crislene.jpg" },
  { name: "Mica T. Dino",              role: "System Analyst",           photo: "images/mica.jpg" },
  { name: "Ryan Stanly A. Navaroza",   role: "Quality Assurance Tester", photo: "images/ryan.jpg" },
  { name: "Jamaica B. Arpon",          role: "Documentation Specialist", photo: "images/jamaica.jpg" },
];

/* ================= Exact fractions ================= */
const gcd=(a,b)=>{if(a<0n)a=-a;if(b<0n)b=-b;while(b){const t=a%b;a=b;b=t;}return a;};
class F{
  constructor(n,d=1n){
    if(typeof n==='number')n=BigInt(n); if(typeof d==='number')d=BigInt(d);
    if(d===0n) throw new Error('Division by zero');
    if(d<0n){n=-n;d=-d;}
    const g=gcd(n,d); if(g>1n){n/=g;d/=g;}
    this.n=n;this.d=d;
  }
  add(o){return new F(this.n*o.d+o.n*this.d,this.d*o.d)}
  sub(o){return new F(this.n*o.d-o.n*this.d,this.d*o.d)}
  mul(o){return new F(this.n*o.n,this.d*o.d)}
  div(o){return new F(this.n*o.d,this.d*o.n)}
  neg(){return new F(-this.n,this.d)}
  inv(){return new F(this.d,this.n)}
  abs(){return this.n<0n?this.neg():this}
  sign(){return this.n>0n?1:this.n<0n?-1:0}
  isZero(){return this.n===0n}
  cmp(o){return this.sub(o).sign()}
  eq(o){return this.n===o.n&&this.d===o.d}
  num(){return Number(this.n)/Number(this.d)}
}
F.ZERO=new F(0n); F.ONE=new F(1n);

/* Reads "3", "-2", "3/4" or "0.5" (decimals become fractions). Returns null if invalid. */
function parseF(s){
  s=String(s).trim().replace(/−/g,'-').replace(/\s+/g,'');
  if(s==='') return F.ZERO;
  let m=s.match(/^([+-]?\d+)\/([+-]?\d+)$/);
  if(m){ if(BigInt(m[2])===0n) return null; return new F(BigInt(m[1]),BigInt(m[2])); }
  m=s.match(/^([+-]?)(\d*)(?:\.(\d*))?$/);
  if(!m||(m[2]===''&&!m[3])) return null;
  const frac=m[3]||'';
  return new F(BigInt((m[2]||'0')+frac)*(m[1]==='-'?-1n:1n),10n**BigInt(frac.length));
}

/* Plain text fraction, e.g. "−3/4" */
const ft=f=>(f.d===1n?f.n.toString():`${f.n}/${f.d}`).replace('-','−');
/* Stacked HTML fraction, like handwriting */
function fh(f){
  if(f.d===1n) return f.n.toString().replace('-','−');
  const neg=f.n<0n;
  return `${neg?'−':''}<span class="fr"><span>${(neg?-f.n:f.n)}</span><span>${f.d}</span></span>`;
}
/* Fraction in parentheses, as in the module: (1/2), (−10) */
const fp=f=>`(${fh(f)})`;

/* ================= Variable names ================= */
const SLACKS=[1,2,3,4,5,6].map(i=>`S<sub>${i}</sub>`);
function decNames(n){ return n===2?['x','y']:Array.from({length:n},(_,j)=>`x<sub>${j+1}</sub>`); }
function decText(n){ return n===2?['x','y']:Array.from({length:n},(_,j)=>`x${j+1}`); }

/* ================= Simplex solver (z-row form, maximization, ≤ constraints) ================= */
function solve(c,A,b){
  const n=c.length, m=A.length, N=n+m;
  const names=[...decNames(n),...SLACKS.slice(0,m)];
  let T=A.map((row,i)=>[...row,...Array.from({length:m},(_,k)=>k===i?F.ONE:F.ZERO)]);
  let rhs=b.slice();
  let z=[...c.map(x=>x.neg()),...Array(m).fill(F.ZERO)], zr=F.ZERO;
  let basis=Array.from({length:m},(_,i)=>n+i);
  const steps=[]; let status='';
  for(let it=0; it<50; it++){
    const st={T:T.map(r=>r.slice()),rhs:rhs.slice(),z:z.slice(),zr,basis:basis.slice(),pc:-1,ratios:null,pr:-1,tieCol:false,tieRow:false,elim:null};
    steps.push(st);
    // pivotal column: most negative entry in the z-row
    let pc=-1;
    z.forEach((v,j)=>{ if(v.sign()<0){ if(pc<0||v.cmp(z[pc])<0) pc=j; else if(v.cmp(z[pc])===0) st.tieCol=true; } });
    if(pc<0){status='optimal';break;}
    st.pc=pc;
    // ratio test
    const ratios=T.map((r,i)=>r[pc].sign()>0?rhs[i].div(r[pc]):null);
    let pr=-1;
    ratios.forEach((q,i)=>{ if(q===null)return; if(pr<0||q.cmp(ratios[pr])<0){pr=i;st.tieRow=false;} else if(q.cmp(ratios[pr])===0) st.tieRow=true; });
    st.ratios=ratios;
    if(pr<0){status='unbounded';break;}
    st.pr=pr;
    // pivotal elimination
    const k=T[pr][pc], invk=k.inv();
    const oldP=[...T[pr],rhs[pr]];
    const newP=oldP.map(v=>v.mul(invk));
    const elim=[{type:'pivot',row:pr,label:names[basis[pr]],invk,items:oldP.map((v,j)=>({old:v,nw:newP[j]}))}];
    const nT=T.map(r=>r.slice()), nR=rhs.slice();
    nT[pr]=newP.slice(0,N); nR[pr]=newP[N];
    for(let i=0;i<m;i++){
      if(i===pr) continue;
      const old=[...T[i],rhs[i]], f=T[i][pc];
      const nw=old.map((v,j)=>v.sub(newP[j].mul(f)));
      elim.push({type:'row',row:i,label:names[basis[i]],f,items:old.map((v,j)=>({old:v,np:newP[j],nw:nw[j]}))});
      nT[i]=nw.slice(0,N); nR[i]=nw[N];
    }
    const oldZ=[...z,zr], fz=z[pc];
    const nwZ=oldZ.map((v,j)=>v.sub(newP[j].mul(fz)));
    elim.push({type:'z',label:'z',f:fz,items:oldZ.map((v,j)=>({old:v,np:newP[j],nw:nwZ[j]}))});
    st.elim=elim;
    T=nT; rhs=nR; z=nwZ.slice(0,N); zr=nwZ[N];
    basis[pr]=pc;
  }
  if(!status) status='limit';
  const last=steps[steps.length-1];
  const val=j=>{const i=last.basis.indexOf(j);return i>=0?last.rhs[i]:F.ZERO;};
  const alt=status==='optimal'?Array.from({length:N},(_,j)=>j).filter(j=>!last.basis.includes(j)&&last.z[j].isZero()):[];
  return {c,A,b,n,m,N,names,steps,status,val,alt};
}

/* ================= Rendering ================= */
function termsHTML(coefs,vars){
  let out='';
  coefs.forEach((f,j)=>{
    if(f.isZero()) return;
    const a=f.abs(), co=(a.eq(F.ONE)?'':fh(a));
    out+= out===''?(f.sign()<0?'−':'')+co+vars[j] : (f.sign()<0?' − ':' + ')+co+vars[j];
  });
  return out||'0';
}

function renderStandard(R){
  const dn=decNames(R.n), sl=SLACKS.slice(0,R.m);
  let zEq='z';
  R.c.forEach((f,j)=>{ if(f.isZero())return; const a=f.abs(), co=a.eq(F.ONE)?'':fh(a); zEq+=(f.sign()>0?' − ':' + ')+co+dn[j]; });
  zEq+=' = 0';
  const lines=R.A.map((row,i)=>termsHTML(row,dn)+` + ${sl[i]} = ${fh(R.b[i])}`);
  return `<div class="card step">
    <div class="step-head"><h3>Step 1 · Convert to standard form</h3><span class="badge">set-up</span></div>
    <div class="stdform">Maximize: &nbsp;z = ${termsHTML(R.c,dn)}<br>Standard form: &nbsp;${zEq}<br>subject to the constraints:<br>${lines.map(l=>'&nbsp;&nbsp;&nbsp;&nbsp;'+l).join('<br>')}<br>&nbsp;&nbsp;&nbsp;&nbsp;${[...dn,...sl].join(', ')} ≥ 0</div>
    <div class="explain"><b>What we did</b><ol>
      <li>Move every term of z to the left side and set it equal to zero: <b>${zEq}</b>.</li>
      ${R.A.map((r,i)=>`<li>Constraint ${i+1} is "≤", so add slack variable <b>${sl[i]}</b>.</li>`).join('')}
      <li>Slack variables are the unused resources. Decision, slack and surplus variables must not be negative.</li>
    </ol></div>
  </div>`;
}

function renderTableau(R,st,num){
  const {pc,pr}=st, showR=!!st.ratios;
  let h=`<div class="scroll"><table class="tab"><thead><tr><th>B.V</th>`;
  R.names.forEach((nm,j)=>h+=`<th class="${j===pc?'pc':''}">${nm}${j===pc?'<span class="tag in">IN</span>':''}</th>`);
  h+=`<th>RHS</th>${showR?'<th class="ratio">Ratio</th>':''}</tr></thead><tbody>`;
  st.T.forEach((row,i)=>{
    const isP=i===pr;
    h+=`<tr class="${isP?'pr':''}"><td class="bv">${R.names[st.basis[i]]}${isP?'<span class="tag out">OUT</span>':''}</td>`;
    row.forEach((v,j)=>h+=`<td class="${j===pc?'pc':''} ${isP&&j===pc?'piv':''}">${fh(v)}</td>`);
    h+=`<td>${fh(st.rhs[i])}</td>`;
    if(showR){const q=st.ratios[i]; h+=`<td class="ratio ${isP?'min':''}">${q===null?'—':fh(q)+(isP?' ✓':'')}</td>`;}
    h+='</tr>';
  });
  h+=`<tr class="zrow"><td class="bv">z</td>${st.z.map((v,j)=>`<td class="${j===pc?'pc':''}">${fh(v)}</td>`).join('')}<td>${fh(st.zr)}</td>${showR?'<td class="ratio"></td>':''}</tr>`;
  return h+'</tbody></table></div>';
}

function renderExplain(R,st,num){
  const nm=R.names, items=[];
  if(st.pc<0){
    items.push(`Look at the z-row: there are <b>no negative entries</b>. This means z cannot increase anymore, so <b>the indicated solution is optimal</b>.`);
  } else {
    items.push(`Look at the z-row. The most negative entry is <b>${fh(st.z[st.pc])}</b> under <b>${nm[st.pc]}</b>, so the <b>${nm[st.pc]}-column is the pivotal column</b> and <b>${nm[st.pc]} is the entering variable</b>.${st.tieCol?' (There is a tie, so we take the leftmost column.)':''}`);
    const lines=st.T.map((r,i)=>{
      const v=r[st.pc], bn=nm[st.basis[i]];
      return v.sign()>0?`${bn}-row: ${fh(st.rhs[i])} ÷ ${fh(v)} = <b>${fh(st.ratios[i])}</b>`:`${bn}-row: entry is ${fh(v)}, not positive, so skip`;
    });
    if(st.pr<0){
      items.push(`Divide each RHS by the positive entries of the pivotal column:<div class="calc">${lines.join('<br>')}</div>There are <b>no positive entries</b> in the pivotal column, so there is <b>no finite optimal solution</b>. z can increase without limit (unbounded).`);
    } else {
      const ex=nm[st.basis[st.pr]];
      items.push(`Find the pivotal row: divide each RHS by the positive entries of the pivotal column.<div class="calc">${lines.join('<br>')}</div>The smallest ratio is <b>${fh(st.ratios[st.pr])}</b>, so the <b>${ex}-row is the pivotal row</b> and <b>${ex} is the exiting variable</b>.${st.tieRow?' (There is a tie, so we take the top row.)':''}`);
      items.push(`The <b>pivot</b> is where the pivotal column and pivotal row meet: <b>k = ${fh(st.T[st.pr][st.pc])}</b>. Next we do pivotal elimination. Multiply the pivotal row by 1/k = <b>${fh(st.T[st.pr][st.pc].inv())}</b>, then compute the other rows.`);
    }
  }
  return `<div class="explain"><b>Tableau ${num} explained</b><ol>${items.map(t=>`<li>${t}</li>`).join('')}</ol></div>`;
}

function renderElim(R,st,num){
  if(!st.elim) return '';
  const cols=[...R.names,'RHS'];
  const ent=R.names[st.pc], ex=R.names[st.basis[st.pr]];
  const boxes=st.elim.map(e=>{
    let lis;
    if(e.type==='pivot') lis=e.items.map((it,j)=>`<li><span class="col">${cols[j]}</span> ${fh(it.old)} ${fp(e.invk)} = <b>${fh(it.nw)}</b></li>`).join('');
    else lis=e.items.map((it,j)=>`<li><span class="col">${cols[j]}</span> ${fh(it.old)} − ${fp(it.np)}${fp(e.f)} = <b>${fh(it.nw)}</b></li>`).join('');
    const title=e.type==='pivot'?`${e.label}-row (pivotal row) × 1/k`:`${e.label}-row`;
    return `<div class="ebox ${e.type==='pivot'?'pivot':''}"><h4>${title}</h4><ul>${lis}</ul></div>`;
  }).join('');
  return `<div class="elim-head"><b>Pivotal elimination (Tableau ${num} → Tableau ${num+1})</b><br>
    <span class="hint">Pivotal row first: entry × (1/k). Every other row: old entry − (new pivotal-row entry)(row's entry in the pivotal column). Then replace the exiting variable <b>${ex}</b> with the entering variable <b>${ent}</b> in B.V.</span></div>
    <div class="elim">${boxes}</div>`;
}

function renderAnswer(R){
  const last=R.steps[R.steps.length-1];
  if(R.status==='unbounded') return `<div class="card step bad"><div class="step-head"><h3>Result: no finite optimal solution</h3><span class="badge bad">unbounded</span></div><p>The pivotal column has no positive entries, so z can increase forever. Check whether a constraint is missing from the problem.</p></div>`;
  if(R.status==='limit') return `<div class="card step bad"><h3>Stopped</h3><p>Too many iterations. Please check the input.</p></div>`;
  const dn=decNames(R.n), dt=decText(R.n), sl=SLACKS.slice(0,R.m);
  const xs=dn.map((_,j)=>R.val(j)), z=last.zr;
  // check by substitution
  const sub1=R.c.map((cf,j)=>`${fh(cf)}${fp(xs[j])}`).join(' + ');
  const sub2=R.c.map((cf,j)=>fh(cf.mul(xs[j]))).join(' + ');
  const meaning=sl.map((s,i)=>{const v=R.val(R.n+i);return v.isZero()?`<li><b>${s} = 0</b>: constraint ${i+1} is fully used (no leftover).</li>`:`<li><b>${s} = ${fh(v)}</b>: constraint ${i+1} has ${fh(v)} unit(s) left unused.</li>`;}).join('');
  const joinSigned=parts=>parts.map((p,i)=>i===0?(p.neg?'−':'')+p.t:(p.neg?' − ':' + ')+p.t).join('');
  const consChecks=R.A.map((row,i)=>{
    const sv=R.val(R.n+i);
    const t1=[],t2=[];
    row.forEach((a,j)=>{ if(a.isZero())return; const aa=a.abs(), v=xs[j];
      t1.push({neg:a.sign()<0,t:aa.eq(F.ONE)?fh(v):fh(aa)+fp(v)}); t2.push({neg:a.sign()<0,t:fh(aa.mul(v))}); });
    t1.push({neg:false,t:fh(sv)}); t2.push({neg:false,t:fh(sv)});
    return `<div class="calc">${termsHTML(row,dn)} + ${sl[i]} = ${fh(R.b[i])}<br>${joinSigned(t1)} = ${fh(R.b[i])}<br>${joinSigned(t2)} = ${fh(R.b[i])}<br>${fh(R.b[i])} = ${fh(R.b[i])} ✓</div>`;
  }).join('');
  const alt=R.alt.length?`<li><b>Alternative optimal solution:</b> non-basic ${R.alt.map(j=>R.names[j]).join(', ')} ${R.alt.length>1?'have':'has'} 0 in the z-row, so another solution gives the same z.</li>`:'';
  return `<div class="card step final">
    <div class="step-head"><h3>Optimal solution</h3><span class="badge good">optimal · Tableau ${R.steps.length}</span></div>
    <div class="answer">
      <div class="zbox"><div class="zl">Maximum value</div><div class="z">z = ${fh(z)}</div></div>
      <div><div class="vals">${dn.map((d,j)=>`<div class="v"><b>${d}</b> = ${fh(xs[j])}</div>`).join('')}${sl.map((s,i)=>`<div class="v" style="font-size:.88rem">${s} = ${fh(R.val(R.n+i))}</div>`).join('')}</div></div>
    </div>
    <div class="explain"><b>Answer and check</b><ol>
      <li>The z-row has no negative entries, so the optimal solution is ${dn.map((d,j)=>`<b>${d} = ${fh(xs[j])}</b>`).join(', ')} and <b>z = ${fh(z)}</b>.</li>
      <li>Check by substituting into the objective function:<div class="calc">z = ${termsHTML(R.c,dn)}<br>${fh(z)} = ${sub1}<br>${fh(z)} = ${sub2}<br>${fh(z)} = ${fh(z)} ✓</div>Both sides are equal.</li>
      <li>Check each constraint, using the values of ${dn.join(', ')} and the slack variables:${consChecks}All constraints are satisfied, so the solution is correct.</li>
      ${meaning}${alt}
    </ol></div>
  </div>`;
}

/* ================= Graph (2 variables only) ================= */
function niceStep(x){const p=Math.pow(10,Math.floor(Math.log10(x)));const r=x/p;return (r<=1?1:r<=2?2:r<=5?5:10)*p;}
function stepFrac(step){ // exact fraction of a tick step like 0.5 or 20
  let k=0; while(Math.abs(step*10**k-Math.round(step*10**k))>1e-9&&k<6)k++;
  return new F(BigInt(Math.round(step*10**k)),10n**BigInt(k));
}
function clipPoly(poly,a,b,c){ // keep a*x + b*y <= c
  const out=[], inside=p=>a*p[0]+b*p[1]<=c+1e-9;
  for(let i=0;i<poly.length;i++){
    const P=poly[i],Q=poly[(i+1)%poly.length],pi=inside(P),qi=inside(Q);
    if(pi) out.push(P);
    if(pi!==qi){const t=(c-a*P[0]-b*P[1])/(a*(Q[0]-P[0])+b*(Q[1]-P[1]));out.push([P[0]+t*(Q[0]-P[0]),P[1]+t*(Q[1]-P[1])]);}
  }
  return out;
}
function cornerPoints(A,b){
  const L=A.map((r,i)=>({a:r[0],b:r[1],c:b[i]}));
  L.push({a:F.ONE,b:F.ZERO,c:F.ZERO},{a:F.ZERO,b:F.ONE,c:F.ZERO});
  const pts=[], seen=new Set();
  for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){
    const p=L[i],q=L[j], det=p.a.mul(q.b).sub(p.b.mul(q.a));
    if(det.isZero()) continue;
    const x=p.c.mul(q.b).sub(p.b.mul(q.c)).div(det), y=p.a.mul(q.c).sub(p.c.mul(q.a)).div(det);
    if(x.sign()<0||y.sign()<0) continue;
    if(!A.every((r,k)=>r[0].mul(x).add(r[1].mul(y)).cmp(b[k])<=0)) continue;
    const key=ft(x)+','+ft(y); if(seen.has(key)) continue; seen.add(key);
    pts.push({x,y});
  }
  pts.sort((p,q)=>p.x.cmp(q.x)||p.y.cmp(q.y));
  return pts;
}
const LINE_COLORS=['#1c2f6b','#b07a00','#2e7d6b','#7a4fa3','#8a5a2b','#5b6478'];
function renderGraph(R,opts={}){
  if(R.n!==2) return '';
  const {A,b,c}=R, pts=cornerPoints(A,b);
  const path=opts.noPath?[]:R.steps.map(st=>{const v=j=>{const i=st.basis.indexOf(j);return i>=0?st.rhs[i]:F.ZERO;};return {x:v(0),y:v(1)};});
  let X=0,Y=0;
  pts.forEach(p=>{X=Math.max(X,p.x.num());Y=Math.max(Y,p.y.num());});
  A.forEach((r,i)=>{const bi=b[i].num(); if(r[0].sign()>0)X=Math.max(X,bi/r[0].num()); if(r[1].sign()>0)Y=Math.max(Y,bi/r[1].num());});
  path.forEach(p=>{X=Math.max(X,p.x.num());Y=Math.max(Y,p.y.num());});
  if(X<=0)X=10; if(Y<=0)Y=10;
  const sX=niceStep(X*1.15/6), sY=niceStep(Y*1.15/6);
  X=Math.ceil(X*1.12/sX)*sX; Y=Math.ceil(Y*1.12/sY)*sY;
  const W=520,H=440,pl=52,pb=40,pt=16,pr=18, pw=W-pl-pr, ph=H-pt-pb;
  const sx=x=>pl+x/X*pw, sy=y=>H-pb-y/Y*ph;
  let g=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Graph of the feasible region"><defs><clipPath id="pa${opts.id||''}"><rect x="${pl}" y="${pt}" width="${pw}" height="${ph}"/></clipPath>
    <marker id="ar${opts.id||''}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#1c2f6b"/></marker></defs>`;
  const fX=stepFrac(sX), fY=stepFrac(sY);
  for(let i=0;i*sX<=X+1e-9;i++){const x=sx(i*sX);g+=`<line x1="${x}" y1="${pt}" x2="${x}" y2="${H-pb}" stroke="#eef0f5"/><text x="${x}" y="${H-pb+16}" font-size="11" text-anchor="middle" fill="#5b6478">${ft(fX.mul(new F(i)))}</text>`;}
  for(let i=0;i*sY<=Y+1e-9;i++){const y=sy(i*sY);g+=`<line x1="${pl}" y1="${y}" x2="${W-pr}" y2="${y}" stroke="#eef0f5"/>${i?`<text x="${pl-8}" y="${y+4}" font-size="11" text-anchor="end" fill="#5b6478">${ft(fY.mul(new F(i)))}</text>`:''}`;}
  // feasible region
  let poly=[[0,0],[X,0],[X,Y],[0,Y]];
  A.forEach((r,i)=>{poly=clipPoly(poly,r[0].num(),r[1].num(),b[i].num());});
  if(poly.length>2) g+=`<polygon points="${poly.map(p=>sx(p[0])+','+sy(p[1])).join(' ')}" fill="rgba(233,165,22,.28)" stroke="#e9a516" stroke-width="1.5"/>`;
  // constraint lines
  g+=`<g clip-path="url(#pa${opts.id||''})">`;
  A.forEach((r,i)=>{
    const a1=r[0].num(),a2=r[1].num(),bi=b[i].num(),col=LINE_COLORS[i%LINE_COLORS.length];
    let x1,y1,x2,y2;
    if(Math.abs(a2)>1e-12){x1=-X;y1=(bi-a1*x1)/a2;x2=2*X;y2=(bi-a1*x2)/a2;} else {x1=x2=bi/a1;y1=-Y;y2=2*Y;}
    g+=`<line x1="${sx(x1)}" y1="${sy(y1)}" x2="${sx(x2)}" y2="${sy(y2)}" stroke="${col}" stroke-width="2.4"/>`;
  });
  g+=`</g>`;
  // axes
  g+=`<line x1="${pl}" y1="${H-pb}" x2="${W-pr}" y2="${H-pb}" stroke="#16213d" stroke-width="1.5"/><line x1="${pl}" y1="${pt}" x2="${pl}" y2="${H-pb}" stroke="#16213d" stroke-width="1.5"/>
    <text x="${W-pr}" y="${H-pb-8}" font-size="13" font-weight="700" text-anchor="end" fill="#16213d">x</text><text x="${pl+8}" y="${pt+12}" font-size="13" font-weight="700" fill="#16213d">y</text>`;
  // simplex path
  for(let i=1;i<path.length;i++){
    const P=path[i-1],Q=path[i]; if(P.x.eq(Q.x)&&P.y.eq(Q.y)) continue;
    g+=`<line x1="${sx(P.x.num())}" y1="${sy(P.y.num())}" x2="${sx(Q.x.num())}" y2="${sy(Q.y.num())}" stroke="#1c2f6b" stroke-width="2" stroke-dasharray="6 4" marker-end="url(#ar${opts.id||''})"/>`;
  }
  // corner points
  let best=null; pts.forEach(p=>{p.z=c[0].mul(p.x).add(c[1].mul(p.y)); if(!best||p.z.cmp(best.z)>0)best=p;});
  const optimal=R.status==='optimal';
  pts.forEach(p=>{
    const isB=optimal&&p===best, px=sx(p.x.num()), py=sy(p.y.num());
    const lx=px+(px>W-110?-8:8), anchor=px>W-110?'end':'start';
    g+=`<circle cx="${px}" cy="${py}" r="${isB?7:4.5}" fill="${isB?'#1d7a4f':'#1c2f6b'}" stroke="#fff" stroke-width="2"/>
       <text x="${lx}" y="${py-9}" font-size="11.5" font-weight="${isB?700:500}" text-anchor="${anchor}" fill="${isB?'#1d7a4f':'#16213d'}" paint-order="stroke" stroke="#fff" stroke-width="3">(${ft(p.x)}, ${ft(p.y)})${isB?' max':''}</text>`;
  });
  g+='</svg>';
  const dn=['x','y'];
  const legend=A.map((r,i)=>`<span><i style="background:${LINE_COLORS[i%LINE_COLORS.length]}"></i>${termsHTML(r,dn)} ≤ ${fh(b[i])}</span>`).join('')+
    `<span><i style="background:rgba(233,165,22,.5)"></i>Feasible region</span>`+(path.length>1?`<span><i style="background:repeating-linear-gradient(90deg,#1c2f6b 0 6px,transparent 6px 10px)"></i>Path of the simplex tableaus</span>`:'');
  const zt=termsHTML(c,dn);
  const table=`<table class="simple"><tr><th>Corner point (x, y)</th><th>z = ${zt}</th></tr>${pts.map(p=>`<tr class="${optimal&&p===best?'best':''}"><td>(${fh(p.x)}, ${fh(p.y)})</td><td>${fh(c[0])}${fp(p.x)} + ${fh(c[1])}${fp(p.y)} = ${fh(p.z)}${optimal&&p===best?' ← maximum':''}</td></tr>`).join('')}</table>`;
  const note=optimal?`<p class="hint" style="margin-top:10px">The largest z at a corner point is <b>${fh(best.z)}</b>, the same answer as the simplex method.${path.length>1?' The dashed arrows show how each tableau moved from one corner point to the next.':''}</p>`
    :`<p class="hint" style="margin-top:10px">The feasible region is not closed in the direction z increases, so z has no maximum.</p>`;
  return `<div class="graphwrap"><div>${g}<div class="glegend">${legend}</div></div><div><b>Corner principle check</b>${table}${note}</div></div>`;
}


/* Graphical method steps: intercepts + point of intersection by elimination */
function graphSteps(R){
  const {A,b}=R, XY=['x','y'];
  const eq=(a,bb,c)=>termsHTML([a,bb],XY)+' = '+fh(c);
  const co=(f,v)=>f.eq(F.ONE)?v:(f.eq(F.ONE.neg())?'−'+v:fh(f)+v);
  let h='<p><b>Step 1 · Intercepts of each constraint</b> (write each as an equation)</p><div class="elim">';
  A.forEach((r,i)=>{
    const [a,bb]=r, c=b[i]; let lines=[];
    lines.push(`<b>${eq(a,bb,c)}</b>`);
    if(!bb.isZero()) lines.push(`Let x = 0: ${co(bb,'y')} = ${fh(c)}${bb.eq(F.ONE)?'':`, y = ${fh(c.div(bb))}`}, thus (0, ${fh(c.div(bb))})`);
    else lines.push(`No y-term: vertical line x = ${fh(c.div(a))}`);
    if(!a.isZero()) lines.push(`Let y = 0: ${co(a,'x')} = ${fh(c)}${a.eq(F.ONE)?'':`, x = ${fh(c.div(a))}`}, thus (${fh(c.div(a))}, 0)`);
    else lines.push(`No x-term: horizontal line y = ${fh(c.div(bb))}`);
    h+=`<div class="ebox"><h4>Constraint ${i+1}</h4><ul>${lines.map(l=>`<li>${l}</li>`).join('')}</ul></div>`;
  });
  h+='</div>';
  const inter=[];
  for(let i=0;i<A.length;i++)for(let j=i+1;j<A.length;j++){
    const [a1,b1]=A[i],[a2,b2]=A[j],c1=b[i],c2=b[j];
    const det=a1.mul(b2).sub(a2.mul(b1)); if(det.isZero()) continue;
    const x=c1.mul(b2).sub(b1.mul(c2)).div(det), y=a1.mul(c2).sub(c1.mul(a2)).div(det);
    if(x.sign()<0||y.sign()<0) continue;
    if(!A.every((r,k)=>r[0].mul(x).add(r[1].mul(y)).cmp(b[k])<=0)) continue;
    const L=[`Eq. ${i+1}: ${eq(a1,b1,c1)}`,`Eq. ${j+1}: ${eq(a2,b2,c2)}`];
    let subEq,sa,sb,sc;
    if(b1.isZero()){ L.push(`From Eq. ${i+1}: ${co(a1,'x')} = ${fh(c1)}, so <b>x = ${fh(x)}</b>`); [sa,sb,sc]=[a2,b2,c2]; subEq=j+1; }
    else if(b2.isZero()){ L.push(`From Eq. ${j+1}: ${co(a2,'x')} = ${fh(c2)}, so <b>x = ${fh(x)}</b>`); [sa,sb,sc]=[a1,b1,c1]; subEq=i+1; }
    else{
      let A1=a1,C1=c1,A2=a2,C2=c2;
      if(!b1.eq(b2)){
        A1=a1.mul(b2);C1=c1.mul(b2);A2=a2.mul(b1);C2=c2.mul(b1);
        L.push('Make the y-terms equal:');
        if(!b2.eq(F.ONE)) L.push(`Eq. ${i+1} × ${fp(b2)} → ${eq(A1,b1.mul(b2),C1)}`);
        if(!b1.eq(F.ONE)) L.push(`Eq. ${j+1} × ${fp(b1)} → ${eq(A2,b2.mul(b1),C2)}`);
      }
      const dx=A1.sub(A2), dc=C1.sub(C2);
      L.push(`Subtract the equations: ${co(dx,'x')} + 0 = ${fh(dc)}`);
      if(!dx.eq(F.ONE)) L.push(`${co(dx,'x')} = ${fh(dc)}, so <b>x = ${fh(x)}</b>`); else L.push(`<b>x = ${fh(x)}</b>`);
      [sa,sb,sc]=[a1,b1,c1]; subEq=i+1;
    }
    const ax=sa.mul(x), rest=sc.sub(ax);
    L.push(`Substitute x = ${fh(x)} into Eq. ${subEq}: ${sa.isZero()?'':(sa.eq(F.ONE)?fp(x):fh(sa)+fp(x))+' + '}${co(sb,'y')} = ${fh(sc)}`);
    if(!sa.isZero()) L.push(`${fh(ax)} + ${co(sb,'y')} = ${fh(sc)} → ${co(sb,'y')} = ${fh(rest)}`);
    L.push(`<b>y = ${fh(y)}</b>, so the point of intersection is <b>(${fh(x)}, ${fh(y)})</b>`);
    inter.push(`<div class="ebox"><h4>Constraints ${i+1} and ${j+1}</h4><ul>${L.map(l=>`<li>${l}</li>`).join('')}</ul></div>`);
  }
  if(inter.length) h+=`<p style="margin-top:14px"><b>Step 2 · Point of intersection</b> (by elimination)</p><div class="elim" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr))">${inter.join('')}</div>`;
  h+=`<p style="margin-top:14px"><b>Step 3 · Graph, shade the feasible region and evaluate z at each corner point</b></p>`;
  return h;
}

function renderSolution(R,opts={}){
  let h=renderStandard(R);
  R.steps.forEach((st,k)=>{
    const num=k+1, isLast=k===R.steps.length-1;
    let badge='';
    if(st.pc>=0&&st.pr>=0) badge=`<span class="badge">${R.names[st.pc]} enters · ${R.names[st.basis[st.pr]]} exits</span>`;
    else if(R.status==='optimal'&&isLast) badge='<span class="badge good">optimal</span>';
    else if(isLast) badge='<span class="badge bad">unbounded</span>';
    h+=`<div class="card step ${isLast?(R.status==='optimal'?'final':'bad'):''}">
      <div class="step-head"><h3>${k===0?'Step 2 · Initial tableau — ':''}Tableau ${num}</h3>${badge}</div>
      ${renderTableau(R,st,num)}${renderExplain(R,st,num)}${renderElim(R,st,num)}</div>`;
  });
  h+=renderAnswer(R);
  if(R.n===2) h+=`<div class="card"><div class="step-head"><h3>Graph of the problem</h3><span class="badge">2 variables</span></div><p class="muted">The graphical method from Module 1, used to check the simplex answer.</p>${graphSteps(R)}${renderGraph(R,{id:opts.id||'s'})}</div>`;
  return h;
}

/* ================= Solver form ================= */
const nvSel=document.getElementById('nv'), ncSel=document.getElementById('nc');
for(let i=2;i<=6;i++) nvSel.add(new Option(i,i));
for(let i=1;i<=6;i++) ncSel.add(new Option(i,i));

function readGrid(){
  return {obj:[...document.querySelectorAll('#objRow input')].map(x=>x.value),
          cons:[...document.querySelectorAll('#consRows .eqline')].map(r=>({a:[...r.querySelectorAll('input.co')].map(x=>x.value),b:r.querySelector('input.rhs').value}))};
}
function esc(s){return String(s??'').replace(/"/g,'&quot;');}
function buildGrid(keep){
  const nv=+nvSel.value, nc=+ncSel.value, old=keep||readGrid(), dn=decNames(nv);
  const inp=(v,cls='')=>`<input type="text" inputmode="text" autocomplete="off" class="${cls}" value="${esc(v)}">`;
  let o=`<div class="eqline"><span class="lab">Max z =</span>`;
  for(let j=0;j<nv;j++) o+=`${j?'<span>+</span>':''}${inp(old.obj[j])}<span class="var">${dn[j]}</span>`;
  document.getElementById('objRow').innerHTML=o+'</div>';
  let c='';
  for(let i=0;i<nc;i++){
    const oc=old.cons[i]||{a:[],b:''};
    c+=`<div class="eqline"><span class="lab">Constraint ${i+1}</span>`;
    for(let j=0;j<nv;j++) c+=`${j?'<span>+</span>':''}${inp(oc.a[j],'co')}<span class="var">${dn[j]}</span>`;
    c+=`<span class="le">≤</span>${inp(oc.b,'rhs')}</div>`;
  }
  document.getElementById('consRows').innerHTML=c;
  document.getElementById('nonneg').innerHTML=dn.join(', ')+' ≥ 0';
}
nvSel.onchange=()=>buildGrid(); ncSel.onchange=()=>buildGrid();

const PROBLEMS={
  m2:    {title:'Module 2 example', obj:['8','10'], cons:[{a:['2','1'],b:'50'},{a:['1','2'],b:'70'}]},
  steel: {title:'Steel producer (slides)', text:'Regular steel: 2 h furnace, 5 h soaking pit, $120 profit. Special steel: 2 h furnace, 3 h soaking pit, $100 profit. Furnace 8 h/day, pit 15 h/day.',
          vars:'x = tons of regular steel, y = tons of special steel', obj:['120','100'], cons:[{a:['2','2'],b:'8'},{a:['5','3'],b:'15'}]},
  burger:{title:'Burger Heaven (slides)', text:'Double burger: 2 patties, 6 pickles, sells $1.50. Triple burger: 3 patties, 3 pickles, sells $1.20. Only 24 patties and 48 pickles left.',
          vars:'x = double burgers, y = triple burgers', obj:['3/2','6/5'], cons:[{a:['2','3'],b:'24'},{a:['6','3'],b:'48'}]},
  three: {title:'Three variables', obj:['5','4','3'], cons:[{a:['2','3','1'],b:'5'},{a:['4','1','2'],b:'11'},{a:['3','4','2'],b:'8'}]},
  sheds: {title:"Bob's sheds (slides)", text:'Small shed: 10 sheets of dry wall, 15 studs, $390 profit. Large shed: 15 sheets, 45 studs, $520 profit. Available: 60 sheets and 135 studs.',
          vars:'x = small sheds, y = large sheds', obj:['390','520'], cons:[{a:['10','15'],b:'60'},{a:['15','45'],b:'135'}]},
  lamps: {title:'Bright and dim lamps (slides)', text:'Bright: 20 min manual, 20 min machine, $15 profit. Dim: 30 min manual, 10 min machine, $10 profit. Manual work 100 h (6000 min), machine 80 h (4800 min) per month.',
          vars:'x = bright lamps, y = dim lamps', obj:['15','10'], cons:[{a:['20','30'],b:'6000'},{a:['20','10'],b:'4800'}]},
  rose:  {title:"Worksheet D2 · Rose's breads", text:'Bread A: 6 lb oats, 4 lb flour, $40 profit. Bread B: 3 lb oats, 5 lb flour, $30 profit. Available: 150 lb oats, 120 lb flour.',
          vars:'x = batches of A, y = batches of B', obj:['40','30'], cons:[{a:['6','3'],b:'150'},{a:['4','5'],b:'120'}]},
  soap:  {title:'Soap product mix', obj:['6','4'], cons:[{a:['3','2'],b:'200'},{a:['3','4'],b:'100'}]},
  business:{title:'Worksheet D1 · Two models', text:'A $260 model yields $85 profit and a $300 model yields $90 profit. Total demand per month will not exceed 135 units.',
          vars:'x = units of the $260 model, y = units of the $300 model', obj:['85','90'], cons:[{a:['1','1'],b:'135'}]},
};
const EXAMPLES=['m2','steel','burger','three'];

function loadProblem(key,run=true){
  const p=PROBLEMS[key];
  nvSel.value=p.obj.length; ncSel.value=p.cons.length; buildGrid(p);
  if(run) runSolve();
}
document.querySelectorAll('[data-ex]').forEach(b=>b.onclick=()=>loadProblem(EXAMPLES[+b.dataset.ex]));
document.getElementById('clearBtn').onclick=()=>{buildGrid({obj:[],cons:[]});document.getElementById('resultsWrap').style.display='none';showErr('');};

function showErr(t){const e=document.getElementById('err');e.innerHTML=t;e.classList.toggle('show',!!t);}
function runSolve(){
  showErr(''); let bad=false;
  const get=el=>{const v=parseF(el.value);el.classList.toggle('bad',v===null);if(v===null)bad=true;return v;};
  const c=[...document.querySelectorAll('#objRow input')].map(get);
  const rows=[...document.querySelectorAll('#consRows .eqline')];
  const A=rows.map(r=>[...r.querySelectorAll('input.co')].map(get));
  const b=rows.map(r=>get(r.querySelector('input.rhs')));
  if(bad){showErr('Some boxes are not numbers. Use whole numbers or fractions like 3/4.');return;}
  if(c.every(x=>x.isZero())){showErr('The objective function is all zeros. Enter at least one coefficient.');return;}
  const e1=A.findIndex(r=>r.every(x=>x.isZero()));
  if(e1>=0){showErr(`Constraint ${e1+1} has all-zero coefficients. Fill it in or lower the number of constraints.`);return;}
  const e2=b.findIndex(x=>x.sign()<0);
  if(e2>=0){rows[e2].querySelector('input.rhs').classList.add('bad');showErr(`Constraint ${e2+1} has a negative right-hand side. In standard form every RHS must be non-negative.`);return;}
  const R=solve(c,A,b);
  document.getElementById('results').innerHTML=renderSolution(R,{id:'s'});
  document.getElementById('resultsWrap').style.display='block';
  document.getElementById('resultsWrap').scrollIntoView({behavior:'smooth',block:'start'});
}
document.getElementById('solveBtn').onclick=runSolve;

/* ================= Modules page ================= */
function modelHTML(p){
  const n=p.obj.length, dn=decNames(n), P=s=>parseF(s);
  return `Max z = ${termsHTML(p.obj.map(P),dn)}<br>${p.cons.map(r=>`&nbsp;&nbsp;${termsHTML(r.a.map(P),dn)} ≤ ${fh(P(r.b))}`).join('<br>')}<br>&nbsp;&nbsp;${dn.join(', ')} ≥ 0`;
}
const MIN_PROBLEMS=[
  {title:"Susan's dog food (slides)", text:'Doggie dinner: 20 g protein, 40 g carbohydrate, 16 cents/cup. Puppy power: 30 g protein, 20 g carbohydrate, 20 cents/cup. The dog needs at least 200 g protein and 180 g carbohydrate.',
   vars:'x = cups of doggie dinner, y = cups of puppy power', model:'Min z = 16x + 20y<br>&nbsp;&nbsp;20x + 30y ≥ 200<br>&nbsp;&nbsp;40x + 20y ≥ 180<br>&nbsp;&nbsp;x, y ≥ 0'},
  {title:'Worksheet D3 · Piggery diet', text:'Pigs need at least 20 units of Substance A and 12 units of Substance B. Type X has 2 units of A and 6 of B and costs $15. Type Y has 6 units of A and 2 of B and costs $35.',
   vars:'x = units of Type X, y = units of Type Y', model:'Min z = 15x + 35y<br>&nbsp;&nbsp;2x + 6y ≥ 20<br>&nbsp;&nbsp;6x + 2y ≥ 12<br>&nbsp;&nbsp;x, y ≥ 0'},
];
document.getElementById('probs').innerHTML=['sheds','steel','burger','lamps','business','rose'].map(k=>{
  const p=PROBLEMS[k];
  return `<div class="prob"><b style="color:var(--navy)">${p.title}</b><p class="muted">${p.text}</p><p>${p.vars}</p><div class="math">${modelHTML(p)}</div><button class="btn small" data-load="${k}">Solve ▸</button></div>`;
}).join('')+MIN_PROBLEMS.map(p=>`<div class="prob"><b style="color:var(--navy)">${p.title}</b><p class="muted">${p.text}</p><p>${p.vars}</p><div class="math">${p.model}</div><span class="tagmin">Minimization · formulation only</span></div>`).join('');
document.querySelectorAll('[data-load]').forEach(b=>b.onclick=()=>{location.hash='solver';setTimeout(()=>loadProblem(b.dataset.load),60);});
(function(){
  const P=PROBLEMS.m2;
  document.getElementById('m2example').innerHTML=renderSolution(solve(P.obj.map(parseF),P.cons.map(r=>r.a.map(parseF)),P.cons.map(r=>parseF(r.b))),{id:'m2'});
  const c=[new F(3),new F(4)], A=[[new F(2),new F(-3)],[new F(4),new F(1)]], b=[new F(5),new F(3)];
  document.getElementById('m1graph').innerHTML=renderGraph({n:2,A,b,c,status:'optimal',steps:[]},{id:'m1',noPath:true});
})();


/* ================= Inequality graphs for Module 1 examples ================= */
function ineqGraph(g){
  const [x0,x1]=g.x,[y0,y1]=g.y, W=380,H=340,p=26, pw=W-2*p, ph=H-2*p;
  const sx=x=>p+(x-x0)/(x1-x0)*pw, sy=y=>H-p-(y-y0)/(y1-y0)*ph;
  const fx=v=>{const f=new F(BigInt(Math.round(v*6)),6n);return ft(f);};
  let s=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Graph"><defs><clipPath id="ig${g.id}"><rect x="${p}" y="${p}" width="${pw}" height="${ph}"/></clipPath></defs>`;
  const st=(x1-x0)>14?2:1;
  for(let x=Math.ceil(x0);x<=x1;x++){ if(x%st)continue; s+=`<line x1="${sx(x)}" y1="${p}" x2="${sx(x)}" y2="${H-p}" stroke="#eef0f5"/>${x?`<text x="${sx(x)}" y="${sy(0)+13}" font-size="9.5" text-anchor="middle" fill="#5b6478">${x}</text>`:''}`; }
  for(let y=Math.ceil(y0);y<=y1;y++){ if(y%st)continue; s+=`<line x1="${p}" y1="${sy(y)}" x2="${W-p}" y2="${sy(y)}" stroke="#eef0f5"/>${y?`<text x="${sx(0)-5}" y="${sy(y)+3}" font-size="9.5" text-anchor="end" fill="#5b6478">${y}</text>`:''}`; }
  let poly=[[x0,y0],[x1,y0],[x1,y1],[x0,y1]];
  g.lines.forEach(l=>{ poly = (l.op==='<'||l.op==='≤') ? clipPoly(poly,l.a,l.b,l.c) : clipPoly(poly,-l.a,-l.b,-l.c); });
  if(poly.length>2) s+=`<polygon points="${poly.map(q=>sx(q[0])+','+sy(q[1])).join(' ')}" fill="rgba(233,165,22,.3)"/>`;
  s+=`<line x1="${p}" y1="${sy(0)}" x2="${W-p}" y2="${sy(0)}" stroke="#16213d" stroke-width="1.3"/><line x1="${sx(0)}" y1="${p}" x2="${sx(0)}" y2="${H-p}" stroke="#16213d" stroke-width="1.3"/>
    <text x="${W-p+4}" y="${sy(0)+4}" font-size="12" font-weight="700" fill="#16213d">x</text><text x="${sx(0)}" y="${p-8}" font-size="12" font-weight="700" text-anchor="middle" fill="#16213d">y</text>`;
  s+=`<g clip-path="url(#ig${g.id})">`;
  g.lines.forEach((l,i)=>{
    const col=LINE_COLORS[i%LINE_COLORS.length], dash=(l.op==='<'||l.op==='>')?' stroke-dasharray="7 5"':'';
    let a,b,c,d; if(Math.abs(l.b)>1e-12){a=x0-1;b=(l.c-l.a*a)/l.b;c=x1+1;d=(l.c-l.a*c)/l.b;} else {a=c=l.c/l.a;b=y0-1;d=y1+1;}
    s+=`<line x1="${sx(a)}" y1="${sy(b)}" x2="${sx(c)}" y2="${sy(d)}" stroke="${col}" stroke-width="2.4"${dash}/>`;
  });
  s+='</g>';
  (g.pts||[]).forEach(q=>{
    const px=sx(q[0]),py=sy(q[1]), right=px<W-90;
    s+=`<circle cx="${px}" cy="${py}" r="4" fill="${q[3]||'#1c2f6b'}" stroke="#fff" stroke-width="1.5"/><text x="${px+(right?7:-7)}" y="${py-7}" font-size="10.5" font-weight="600" text-anchor="${right?'start':'end'}" fill="#16213d" paint-order="stroke" stroke="#fff" stroke-width="3">${q[2]||'('+fx(q[0])+', '+fx(q[1])+')'}</text>`;
  });
  s+='</svg>';
  const leg=g.lines.map((l,i)=>`<span><i style="background:${LINE_COLORS[i%LINE_COLORS.length]}"></i>${l.t} &nbsp;<span class="hint">${(l.op==='<'||l.op==='>')?'dashed: not included':'solid: included'}</span></span>`).join('')+`<span><i style="background:rgba(233,165,22,.55)"></i>Shaded: solution</span>`;
  return s+`<div class="glegend">${leg}</div>`;
}
const IGRAPHS={
  e2a:{x:[-6,6],y:[-3,8],lines:[{a:-1,b:1,c:2,op:'>',t:'y > x + 2'}],pts:[[0,2],[-2,0]]},
  e2b:{x:[-6,5],y:[-3,9],lines:[{a:-2,b:1,c:3,op:'>',t:'y > 2x + 3'}],pts:[[0,3],[-1.5,0]]},
  e2c:{x:[-3,7],y:[-2,10],lines:[{a:3,b:1,c:6,op:'≥',t:'y ≥ −3x + 6'}],pts:[[0,6],[2,0]]},
  e2d:{x:[-8,4],y:[-5,6],lines:[{a:1,b:0,c:-4,op:'≥',t:'x ≥ −4'}],pts:[[-4,0]]},
  e3a:{x:[-2,6],y:[-3,12],lines:[{a:4,b:1,c:8,op:'≥',t:'4x + y ≥ 8'},{a:1,b:0,c:3,op:'≤',t:'x ≤ 3'}],pts:[[0,8],[2,0],[2.5,4,'(5/2, 4) check','#1d7a4f']]},
  e3b:{x:[-4,4],y:[-3,6],lines:[{a:3,b:2,c:3,op:'≤',t:'3x + 2y ≤ 3'},{a:4,b:5,c:4,op:'≥',t:'4x + 5y ≥ 4'}],pts:[[0,1.5],[0,0.8,'(0, 4/5)'],[1,0],[-1,2,'(−1, 2) check','#1d7a4f']]},
};
document.querySelectorAll('.ig').forEach(el=>{const k=el.dataset.g;el.innerHTML=ineqGraph({id:k,...IGRAPHS[k]});});

/* ================= Team page ================= */
const ini=name=>name.replace(/[^A-Za-z ]/g,'').split(/\s+/).filter(w=>w.length>1).map(w=>w[0]);
document.getElementById('teacherCard').innerHTML=`
  <h2>Our Teacher</h2>
  <img class="photo" src="${TEACHER.photo}" alt="${TEACHER.name}">
  <div><div class="tname">${TEACHER.name}</div>
  <div class="subj">📘 Subject: <b>${TEACHER.subject}</b></div>
  <blockquote>“${TEACHER.quote}”</blockquote></div>`;
document.getElementById('teamGrid').innerHTML=TEAM.map(t=>{
  const i=ini(t.name), initials=(i[0]||'')+(i[i.length-1]||'');
  const pic=t.photo?`<img class="avatar" src="${t.photo}" alt="${t.name}">`:`<div class="avatar">${initials.toUpperCase()}</div>`;
  return `<div class="member">${pic}<h3>${t.name}</h3><div class="role">${t.role}</div></div>`;
}).join('');

/* ================= Flashcards ================= */
const CARDS=[
  ['How do you choose the pivotal column?','The column with the most negative entry in the z-row.'],
  ['How do you choose the pivotal row?','Divide each RHS by the positive entries of the pivotal column. The smallest ratio is the pivotal row.'],
  ['What is the pivot?','The intersection of the pivotal column and the pivotal row.'],
  ['First step of pivotal elimination?','Multiply every entry of the pivotal row by 1/k, where k is the pivot.'],
  ['Formula for the other rows?','New entry = old entry − (new pivotal-row entry)(row\'s entry in the pivotal column).'],
  ['When is the tableau optimal?','When the z-row has no negative entries.'],
  ['What variable is added to a "≤" constraint?','A slack variable (S₁, S₂, S₃, …): the unused resource.'],
  ['How is z written in standard form?','Move all terms to the left: z − c₁x − c₂y = 0.'],
  ['When is there no finite optimal solution?','When the pivotal column has no positive entries.'],
  ['When do we use x₁, x₂, x₃?','When there are more than two decision variables. With two, use x and y.'],
];
document.getElementById('cards').innerHTML=CARDS.map(([q,a])=>`<div class="flip" tabindex="0"><div class="inner"><div class="face front">${q}<small>TAP TO FLIP</small></div><div class="face back">${a}</div></div></div>`).join('');
document.querySelectorAll('.flip').forEach(f=>{f.onclick=()=>f.classList.toggle('on');f.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();f.classList.toggle('on');}};});

/* ================= Page switching ================= */
const PAGES=['home','solver','modules','reviewer','team'];
function route(){
  let h=location.hash.replace('#','');
  if(!PAGES.includes(h)) h='home';
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+h));
  document.querySelectorAll('#tabs a').forEach(a=>a.classList.toggle('active',a.dataset.p===h));
  window.scrollTo(0,0);
}
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-jump]').forEach(a=>a.onclick=e=>{e.preventDefault();const t=document.querySelector(a.getAttribute('href'));const y=t.getBoundingClientRect().top+scrollY-(document.querySelector('header').offsetHeight+10);window.scrollTo({top:y,behavior:'smooth'});});

loadProblem('m2',false);
route();
